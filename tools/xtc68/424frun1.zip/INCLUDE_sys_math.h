#ifndef _SYS_MATH_H
#define _SYS_MATH_H
extern const double _HUGE_VALUE;
extern const double _Infinity;
#endif
