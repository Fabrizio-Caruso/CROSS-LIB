#ifndef _UNCTRL_H
#define _UNCTRL_H
#define unctrl(c) (_unctrl[ (unsigned char) c ])
extern char *_unctrl[];
#endif
